#ifndef HARDWARECONTROL_H
#define HARDWARECONTROL_H

#include "Centipede.h"

#include "IBuzzer.h"
#include "ICoin.h"
#include "ILock.h"
#include "IMotor.h"
#include "IProgram.h"
#include "ISoap.h"
#include "ITemperature.h"
#include "IWater.h"

class HardwareControl : public ICoin, public IProgram
{
  public:
    HardwareControl();
    Centipede centipede;

    // Inputs
    boolean GetClear();
    boolean GetCoin10();
    boolean GetCoin50();
    boolean GetCoin200();
    boolean GetCoinClear();
    boolean GetStartButton();
    boolean GetProgramButton();
    boolean GetLockSwitch();
    boolean GetSoap1Switch();
    boolean GetSoap2Switch();
    boolean GetPressureSwitch();
    int GetMotorSpeed();
    int GetTemperature();
    int GetWaterLevel();

    // Outputs
    void SetClear();
    void SetCoin10(int leds);
    void SetCoin50(int leds);
    void SetCoin200(int leds);
    void SetBuzzerOn();
    void SetBuzzerOff();
    void SetSoap1(int level);
    void SetSoap2(int level);
    void SetDrain(int level);
    void SetSinkOpen();
    void SetSinkClosed();
    void SetDirection(int dir); //0=left 1=right
    void SetMotorSpeed(int value); //0=off 1=slow 2=medium 3=high
    void SetProgramIndicator(int program); //0=off 1=A 2=B 3=C
    void Lock();
    void SetLockLed(int level);
    void SetHeaterOn();
    void SetHeaterOff();

  private:
    void SetKeySelect(int value);
    void SetGroup(unsigned char group);
    void SetData(unsigned char data);
    void Strobe();

    boolean KeySelectButtonPressed(const int* button);
    boolean KeySelectSwitchOn(const int* switches);
    void SetLeds(int leds);
    int motorSpeed;
};

#endif
