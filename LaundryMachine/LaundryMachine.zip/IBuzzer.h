#ifndef IBUZZER_H
#define IBUZZER_H

class IBuzzer
{
public:
  virtual void SetBuzzer(int level) = 0;
};

#endif


