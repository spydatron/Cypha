#ifndef ILOCK_H
#define ILOCK_H

class ILock
{
public:
  // Inputs

  // Outputs
};

#endif


