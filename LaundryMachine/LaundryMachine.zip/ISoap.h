#ifndef ISOAP_H
#define ISOAP_H

class ISoap
{
public:
  // Inputs

  // Outputs
  virtual void SetSoap2(int level) = 0;
};

#endif


